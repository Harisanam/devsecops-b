import React from 'react';

const SnippetList = ({ snippets, onEdit, onDelete }) => {
  return (
    <div className="max-w-3xl mx-auto mt-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-4">Your Snippets</h2>
      <ul className="space-y-4">
        {snippets.map((snippet) => (
          <li key={snippet.id} className="bg-white p-4 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold text-gray-800">{snippet.title}</h3>
            <p className="text-gray-600">{snippet.content}</p>
            <div className="mt-4 flex space-x-4">
              <button
                onClick={() => onEdit(snippet)}
                className="px-4 py-2 bg-yellow-500 text-white rounded-md hover:bg-yellow-600"
              >
                Edit
              </button>
              <button
                onClick={() => onDelete(snippet.id)}
                className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600"
              >
                Delete
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default SnippetList;
