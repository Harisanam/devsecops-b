
import React from 'react';


function Register() {
  const registerUser = (event) => {
    event.preventDefault();
    // Tambahkan logika registrasi di sini
  };

  return (
    <div className="bg-[#f1f6fa] min-h-screen flex items-center justify-center">
      <div className="w-full max-w-md p-8 bg-white rounded-lg shadow-lg">
        <h2 className="text-3xl font-bold text-[#002b4e] text-center mb-6">Create an Account</h2>
        <form onSubmit={registerUser} className="space-y-4">
          <div>
            <label htmlFor="register-username" className="block text-sm font-semibold">Username</label>
            <input type="text" id="register-username" className="w-full p-3 border rounded-md" required />
          </div>
          <div>
            <label htmlFor="register-email" className="block text-sm font-semibold">Email</label>
            <input type="email" id="register-email" className="w-full p-3 border rounded-md" required />
          </div>
          <div>
            <label htmlFor="register-password" className="block text-sm font-semibold">Password</label>
            <input type="password" id="register-password" className="w-full p-3 border rounded-md" required />
          </div>
          <button type="submit" className="w-full bg-blue-500 text-white py-3 rounded-md">Register</button>
        </form>
      </div>
    </div>
  );
}

export default Register;
