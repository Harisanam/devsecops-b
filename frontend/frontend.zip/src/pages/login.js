// src/pages/Login.js
import React from 'react';


function Login() {
  const loginUser = (event) => {
    event.preventDefault();
    // Logika untuk login di sini
  };

  return (
    <div className="bg-[#f1f6fa] min-h-screen flex items-center justify-center">
      <div className="w-full max-w-md p-8 bg-white rounded-lg shadow-lg">
        <h2 className="text-3xl font-bold text-[#002b4e] text-center mb-6">Login to Your Account</h2>
        <form onSubmit={loginUser} className="space-y-4">
          <div>
            <label htmlFor="username" className="block text-sm font-semibold text-[#607d94]">Username</label>
            <input type="text" id="username" className="w-full p-3 border rounded-md" required />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-semibold text-[#607d94]">Password</label>
            <input type="password" id="password" className="w-full p-3 border rounded-md" required />
          </div>
          <button type="submit" className="w-full bg-[#185cff] text-white py-3 rounded-md hover:bg-[#003b6f] transition">Login</button>
        </form>
        <p className="text-center text-sm text-[#607d94] mt-4">
          Don't have an account? 
          <a href="/register" className="text-[#185cff] font-semibold">Register</a>
        </p>
      </div>
    </div>
  );
}

export default Login;
