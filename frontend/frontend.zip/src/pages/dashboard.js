import React from 'react';



function Dashboard() {
  return (
    <div className="bg-gray-100 min-h-screen flex flex-col items-center">
      {/* Navbar */}
      <nav className="bg-blue-500 w-full shadow-lg p-4">
        <div className="container mx-auto flex justify-between items-center max-w-4xl">
          <h1 className="text-white text-2xl font-semibold">Dashboard</h1>
          <button onClick={() => alert('Logout')} className="text-white">Logout</button>
        </div>
      </nav>

      {/* Main Content */}
      <div className="container mx-auto py-8 px-4 max-w-4xl">
        <h2 className="text-3xl font-semibold text-gray-700 text-center mb-6">Welcome, <span id="username"></span>!</h2>
        
        <section className="bg-white shadow-md rounded-lg p-6 mb-8">
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">Your Snippets</h3>
          <div className="space-y-4">
            {/* Placeholder for snippets */}
          </div>
        </section>

        <section className="bg-white shadow-md rounded-lg p-6">
          <h3 className="text-2xl font-semibold text-gray-800 mb-4">Add New Snippet</h3>
          <form onSubmit={(e) => e.preventDefault()} className="space-y-4">
            <input type="text" placeholder="Title" className="w-full p-3 border rounded-md" />
            <textarea placeholder="Content" className="w-full p-3 border rounded-md"></textarea>
            <button type="submit" className="w-full bg-blue-500 text-white py-3 rounded-md">Add Snippet</button>
          </form>
        </section>
      </div>
    </div>
    
  );
  

}

export default Dashboard;
